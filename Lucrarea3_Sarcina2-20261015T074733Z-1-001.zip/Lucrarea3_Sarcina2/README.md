# Sarcina 2 – Workflow „Plasează comanda” (soluție)

Soluție minimală pentru Sarcinile 2 și 3 din [Lucrarea 3](../README.md), pornind de la coșul din [Lucrarea 2](../../Lucrarea-02/Sarcina2-ShoppingCart/).

## Ce s-a schimbat față de Lucrarea 2

| Lucrarea 2 | Lucrarea 3 |
|---|---|
| Constructori publici, fără validări | Tipuri valoare cu `Create(...)` care întorc `Result` (`ProductCode`, `Quantity`, `Address`) |
| Tranziții care ignoră erorile (`_ => cart`) | Operații care întorc `Result<StareaUrmătoare, PlaceOrderError>` |
| Meniu interactiv, o stare modificată pas cu pas | Un singur workflow compus cu `Bind`/`Map` |
| Fără rezultat final | `OrderPlacedEvent` (succes) sau `PlaceOrderError` (eșec) |

## Structura

| Cerință | Unde se vede |
|---|---|
| Validare + conversie la tipuri DDD | `OrderOperations.Validate` (adună **toate** erorile) |
| Existența produsului | `OrderOperations.CheckProducts` |
| Verificarea stocului | `OrderOperations.CheckStock` |
| Verificarea adresei de livrare | `OrderOperations.CheckDeliveryAddress` (livrăm doar în orașe din listă) |
| Calculul prețului | `OrderOperations.Price` (transport 20 lei, gratuit de la 500 lei) |
| Compunerea pașilor | `PlaceOrderWorkflow.Execute` |
| Succes / eșec | `OrderPlacedEvent` / `PlaceOrderError`, în `Result<,>` |
| Stările comenzii | `States/OrderStates.cs`: nevalidată → validată → rezolvată → prețuită |
| Aplicație consolă | `ShoppingCart/Program.cs` |
| Teste xunit (validare valid/invalid + workflow) | `ShoppingCart.Tests/PlaceOrderTests.cs` |

## În ce ordine citești codul

Fiecare fișier are comentarii care explică ce face și de ce. Ordinea recomandată:

1. `Result.cs` – ce este un `Result` (Ok / Error) și cum funcționează `Match`, `Map` și `Bind`.
2. `Models/` – tipurile valoare (`ProductCode`, `Quantity`, `Address`) și metoda lor `Create`, plus `Customer` și `Product`.
3. `PlaceOrderCommand.cs` – datele brute primite de la utilizator.
4. `States/OrderStates.cs` – etapele prin care trece o comandă.
5. `PlaceOrderError.cs` și `OrderPlacedEvent.cs` – cele două rezultate posibile (eșec / succes).
6. `Operations/OrderOperations.cs` – fiecare pas al workflow-ului, pe rând.
7. `PlaceOrderWorkflow.cs` – cum se leagă pașii cu `Bind` și `Map`.
8. `Program.cs` – aplicația consolă care folosește workflow-ul.
9. `ShoppingCart.Tests/PlaceOrderTests.cs` – exemple concrete de comenzi reușite și eșuate.

## Rulare

```
dotnet run --project ShoppingCart
dotnet test
```

## Idei de reținut

* Workflow-ul este o **funcție pură**: catalogul, orașele și ora vin ca parametri, deci testele nu au nevoie de mock-uri.
* **Railway**: pe succes se trece la pasul următor, la prima eroare se sare la final.
* Validarea adună toate erorile; pașii următori (catalog, stoc, adresă) depind de cei dinainte, deci se opresc la prima categorie de eroare.
* Un **eveniment** descrie un fapt petrecut; un eșec nu s-a petrecut, deci este o **eroare**.
* Stocul nu este scăzut după comandă: nu avem persistență în această lucrare.
