using ShoppingCart.Models;
using ShoppingCart.Operations;
using ShoppingCart.States;
using Xunit;

namespace ShoppingCart.Tests;

// =====================================================================================
// Teste xUnit pentru validare și pentru workflow-ul complet.
// =====================================================================================
// Fiecare test urmează structura "Arrange – Act – Assert":
//   Arrange – pregătim datele de intrare
//   Act     – apelăm codul testat
//   Assert  – verificăm rezultatul
//
// Pentru că workflow-ul este o funcție pură, îi dăm direct catalogul, orașele și ora,
// fără bază de date și fără mock-uri.
// =====================================================================================
public class PlaceOrderTests
{
    // Coduri de produs folosite în teste.
    private static readonly ProductCode Laptop = Code("LP001");
    private static readonly ProductCode Mouse = Code("MS002");

    // Un catalog mic, doar pentru teste. Mouse-ul are intenționat stoc mic (2), ca să putem testa lipsa de stoc.
    private static readonly Dictionary<ProductCode, Product> Catalog = new()
    {
        [Laptop] = new Product(Laptop, "Laptop", 3500m, 5),
        [Mouse] = new Product(Mouse, "Mouse", 80m, 2),
    };

    // Livrăm doar în Timișoara (pentru testul cu oraș nepermis).
    private static readonly HashSet<string> Cities = new(["Timișoara"], StringComparer.OrdinalIgnoreCase);

    // Creează un ProductCode valid sau aruncă excepție (în teste știm că folosim coduri corecte).
    private static ProductCode Code(string raw) =>
        ProductCode.Create(raw).Match(c => c, e => throw new InvalidOperationException(e));

    // Creează o comandă validă implicit; fiecare test schimbă doar câmpul care îl interesează.
    private static PlaceOrderCommand Command(string code = "MS002", string quantity = "1", string city = "Timișoara", string postal = "300006") =>
        new("Ana", [new UnvalidatedLine(code, quantity)], "Bd. Vasile Pârvan 2", city, postal);

    // Rulează workflow-ul cu datele de test. Ora este fixă (UnixEpoch), ca testele să fie repetabile.
    private static Result<OrderPlacedEvent, PlaceOrderError> Run(PlaceOrderCommand command) =>
        PlaceOrderWorkflow.Execute(command, Catalog, Cities, DateTimeOffset.UnixEpoch);

    // ---- Validare (Sarcina 3 din laborator): un caz valid și unul invalid ----

    [Fact]
    public void Validate_ValidInput_ReturnsValidatedOrder()
    {
        // Arrange: date corecte (codul este scris cu litere mici intenționat).
        var order = new UnvalidatedOrder("Ana", [new UnvalidatedLine("lp001", "2")], "Str. Test 1", "Timișoara", "300006");

        // Act
        var result = OrderOperations.Validate(order);

        // Assert: rezultatul trebuie să fie Ok, cu datele transformate corect.
        var ok = Assert.IsType<Result<ValidatedOrder, PlaceOrderError>.Ok>(result);
        Assert.Equal("Ana", ok.Value.Customer.Name);
        Assert.Equal(Laptop, ok.Value.Lines[0].Code); // codul a fost normalizat la litere mari
        Assert.Equal(2, ok.Value.Lines[0].Quantity.Value);
    }

    [Fact]
    public void Validate_InvalidInput_ReturnsAllErrors()
    {
        // Arrange: nume gol, cod greșit, cantitate 0, cod poștal prea scurt.
        var order = new UnvalidatedOrder("", [new UnvalidatedLine("xx", "0")], "Str. Test 1", "Timișoara", "12");

        // Act
        var result = OrderOperations.Validate(order);

        // Assert: rezultatul este Error de tip Validation și conține TOATE cele 4 probleme.
        var error = Assert.IsType<Result<ValidatedOrder, PlaceOrderError>.Error>(result);
        var validation = Assert.IsType<PlaceOrderError.Validation>(error.Value);
        Assert.Equal(4, validation.Messages.Count); // nume, cod, cantitate, cod poștal
    }

    // ---- Workflow ----

    [Fact]
    public void Workflow_ValidOrder_ProducesEventWithShipping()
    {
        // 1 mouse = 80 lei, sub pragul de 500 lei, deci se adaugă transportul de 20 lei.
        var ok = Assert.IsType<Result<OrderPlacedEvent, PlaceOrderError>.Ok>(Run(Command()));

        Assert.Equal(80m, ok.Value.Subtotal);
        Assert.Equal(OrderOperations.ShippingFee, ok.Value.ShippingCost);
        Assert.Equal(100m, ok.Value.Total);
    }

    [Fact]
    public void Workflow_LargeOrder_HasFreeShipping()
    {
        // 1 laptop = 3500 lei, peste prag, deci transportul este gratuit.
        var ok = Assert.IsType<Result<OrderPlacedEvent, PlaceOrderError>.Ok>(Run(Command("LP001", "1")));

        Assert.Equal(0m, ok.Value.ShippingCost);
        Assert.Equal(3500m, ok.Value.Total);
    }

    [Fact]
    public void Workflow_UnknownProduct_Fails()
    {
        // "ZZ999" are format corect, dar nu există în catalog -> eșuează la pasul 2.
        var error = Assert.IsType<Result<OrderPlacedEvent, PlaceOrderError>.Error>(Run(Command("ZZ999")));

        Assert.IsType<PlaceOrderError.UnknownProducts>(error.Value);
    }

    [Fact]
    public void Workflow_NotEnoughStock_Fails()
    {
        // Cerem 3 mouse-uri, dar avem doar 2 în stoc -> eșuează la pasul 3.
        var error = Assert.IsType<Result<OrderPlacedEvent, PlaceOrderError>.Error>(Run(Command("MS002", "3")));

        var stock = Assert.IsType<PlaceOrderError.InsufficientStock>(error.Value);
        Assert.Equal(2, stock.Shortages[0].Available);
    }

    [Fact]
    public void Workflow_CityWithoutDelivery_Fails()
    {
        // Nu livrăm în Brașov -> eșuează la pasul 4.
        var error = Assert.IsType<Result<OrderPlacedEvent, PlaceOrderError>.Error>(Run(Command(city: "Brașov")));

        Assert.IsType<PlaceOrderError.DeliveryNotAvailable>(error.Value);
    }
}
