using ShoppingCart.Models;
using ShoppingCart.Operations;
using ShoppingCart.States;

namespace ShoppingCart;

// =====================================================================================
// PlaceOrderWorkflow – WORKFLOW-UL complet "plasează comanda".
// =====================================================================================
// Aici legăm toți pașii din OrderOperations într-un singur "lanț", folosind Bind și Map.
//
// Cum funcționează lanțul (ideea de "cale ferată" / railway):
//
//   Validate ──Bind──> CheckProducts ──Bind──> CheckStock ──Bind──> CheckDelivery ──Map──> Price ──Map──> Eveniment
//      │                   │                      │                     │
//      └───── Error ───────┴────── Error ─────────┴──────── Error ──────┴──────────────────────────────> Error
//
//   - Dacă un pas reușește (Ok), rezultatul lui este dat automat pasului următor.
//   - Dacă un pas eșuează (Error), toți pașii rămași sunt SĂRIȚI și eroarea ajunge direct la final.
//
// Când folosim Bind și când Map?
//   - Bind: pentru pașii care POT eșua (întorc Result): CheckProducts, CheckStock, CheckDeliveryAddress.
//   - Map:  pentru pașii care NU pot eșua (întorc o valoare simplă): Price, crearea evenimentului.
//
// Fără Bind, același cod ar arăta cam așa (mult mai lung și mai ușor de greșit):
//
//   var validated = Validate(...);
//   if (validated is Error e1) return e1;
//   var resolved = CheckProducts(validated.Value, catalog);
//   if (resolved is Error e2) return e2;
//   var inStock = CheckStock(resolved.Value);
//   if (inStock is Error e3) return e3;
//   ... și tot așa
//
// Workflow-ul este o FUNCȚIE PURĂ: catalogul, orașele și ora curentă vin ca parametri.
// Astfel, în teste putem da exact datele pe care le vrem, fără baze de date sau mock-uri.
// =====================================================================================
public static class PlaceOrderWorkflow
{
    public static Result<OrderPlacedEvent, PlaceOrderError> Execute(
        PlaceOrderCommand command,
        IReadOnlyDictionary<ProductCode, Product> catalog,
        IReadOnlySet<string> deliveryCities,
        DateTimeOffset now)
    {
        // Transformăm comanda primită de la utilizator în prima stare a comenzii.
        UnvalidatedOrder unvalidatedOrder = new UnvalidatedOrder(
            command.CustomerName,
            command.Lines,
            command.Street,
            command.City,
            command.PostalCode);

        return OrderOperations.Validate(unvalidatedOrder)                              // Pasul 1: UnvalidatedOrder -> ValidatedOrder
            .Bind(validated => OrderOperations.CheckProducts(validated, catalog))      // Pasul 2: ValidatedOrder   -> ResolvedOrder
            .Bind(resolved => OrderOperations.CheckStock(resolved))                    // Pasul 3: ResolvedOrder    -> ResolvedOrder
            .Bind(resolved => OrderOperations.CheckDeliveryAddress(resolved, deliveryCities)) // Pasul 4: ResolvedOrder -> ResolvedOrder
            .Map(resolved => OrderOperations.Price(resolved))                          // Pasul 5: ResolvedOrder    -> PricedOrder
            .Map(priced => CreateEvent(priced, now));                                  // Final:   PricedOrder      -> OrderPlacedEvent
    }

    // Construiește evenimentul de succes pe baza comenzii prețuite.
    private static OrderPlacedEvent CreateEvent(PricedOrder priced, DateTimeOffset now)
    {
        return new OrderPlacedEvent(
            OrderId: Guid.NewGuid(),
            Customer: priced.Customer,
            Lines: priced.Lines,
            DeliveryAddress: priced.DeliveryAddress,
            Subtotal: priced.Subtotal,
            ShippingCost: priced.ShippingCost,
            Total: priced.Total,
            PlacedAt: now);
    }
}
