using System.Text.RegularExpressions;

namespace ShoppingCart.Models;

// =====================================================================================
// Address – TIP VALOARE pentru adresa de livrare.
// =====================================================================================
// Format valid:
//   - strada nu este goală
//   - orașul nu este gol
//   - codul poștal are exact 6 cifre (ex. "300006")
//
// Atenție: aici verificăm doar FORMATUL adresei. Faptul că livrăm sau nu în acel oraș
// este o regulă de afaceri separată, verificată mai târziu în
// OrderOperations.CheckDeliveryAddress.
// =====================================================================================
public sealed partial record Address
{
    public string Street { get; }
    public string City { get; }
    public string PostalCode { get; }

    // Constructor privat: o adresă se creează doar prin Create.
    private Address(string street, string city, string postalCode)
    {
        Street = street;
        City = city;
        PostalCode = postalCode;
    }

    // Validează cele trei câmpuri și întoarce Ok(Address) sau Error(mesaj).
    public static Result<Address, string> Create(string? street, string? city, string? postalCode)
    {
        // Pasul 1: normalizăm textele (null devine "", eliminăm spațiile de la capete).
        string cleanStreet = (street ?? "").Trim();
        string cleanCity = (city ?? "").Trim();
        string cleanPostalCode = (postalCode ?? "").Trim();

        // Pasul 2: strada și orașul sunt obligatorii.
        if (cleanStreet.Length == 0 || cleanCity.Length == 0)
        {
            return new Result<Address, string>.Error("Adresa trebuie să conțină strada și orașul");
        }

        // Pasul 3: codul poștal trebuie să aibă exact 6 cifre.
        if (!PostalPattern().IsMatch(cleanPostalCode))
        {
            return new Result<Address, string>.Error($"Cod poștal invalid: '{postalCode}' (6 cifre)");
        }

        // Toate verificările au trecut: putem crea adresa.
        return new Result<Address, string>.Ok(new Address(cleanStreet, cleanCity, cleanPostalCode));
    }

    // Exemplu de afișare: "Bd. Vasile Pârvan 2, Timișoara, 300006"
    public override string ToString() => $"{Street}, {City}, {PostalCode}";

    // ^\d{6}$ = de la început până la sfârșit, exact 6 cifre.
    [GeneratedRegex(@"^\d{6}$")]
    private static partial Regex PostalPattern();
}
