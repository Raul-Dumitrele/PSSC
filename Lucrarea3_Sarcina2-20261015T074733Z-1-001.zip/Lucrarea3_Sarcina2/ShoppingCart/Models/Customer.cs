namespace ShoppingCart.Models;

// =====================================================================================
// Customer – TIP ENTITATE (Entity) pentru clientul care plasează comanda.
// =====================================================================================
// Diferența dintre ENTITATE și TIP VALOARE:
//   - Un tip valoare (ex. ProductCode, Address) este definit doar de valorile lui:
//     două adrese cu aceeași stradă, oraș și cod poștal sunt "aceeași adresă".
//   - O entitate are o IDENTITATE proprie (aici: Id). Doi clienți pe care îi cheamă
//     "Ana" sunt totuși persoane diferite, pentru că au Id-uri diferite.
// =====================================================================================
public sealed record Customer(Guid Id, string Name);
