namespace ShoppingCart.Models;

// =====================================================================================
// Product – un produs din catalogul magazinului.
// =====================================================================================
//   Code      – codul unic al produsului (deja validat, vezi ProductCode)
//   Name      – numele afișat (ex. "Laptop")
//   UnitPrice – prețul pentru o bucată, în lei
//   Stock     – câte bucăți avem disponibile în depozit
// =====================================================================================
public sealed record Product(ProductCode Code, string Name, decimal UnitPrice, int Stock);
