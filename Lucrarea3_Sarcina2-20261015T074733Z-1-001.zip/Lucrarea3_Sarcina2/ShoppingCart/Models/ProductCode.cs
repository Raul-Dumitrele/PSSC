using System.Text.RegularExpressions;

namespace ShoppingCart.Models;

// =====================================================================================
// ProductCode – TIP VALOARE (Value Object) pentru codul unui produs.
// =====================================================================================
// Format valid: două litere mari urmate de trei cifre (ex. "LP001", "MS002").
//
// De ce nu folosim simplu un string?
//   Un string poate conține orice ("", "abc", "123456"). Un ProductCode, în schimb,
//   poate fi creat DOAR prin metoda Create, care verifică formatul. Deci, oriunde în
//   program primești un ProductCode, știi sigur că este valid – nu mai trebuie verificat.
//
// "Tip valoare" înseamnă că două coduri cu același text sunt considerate egale
// (record-urile din C# compară automat după valori).
// =====================================================================================
public sealed partial record ProductCode
{
    // Textul codului, deja normalizat (fără spații, cu litere mari).
    public string Value { get; }

    // Constructor PRIVAT: din afara clasei nu se poate scrie "new ProductCode(...)".
    // Singura cale de a obține un ProductCode este metoda Create de mai jos.
    private ProductCode(string value)
    {
        Value = value;
    }

    // Create = "constructor inteligent" (smart constructor).
    // Primește textul brut introdus de utilizator (poate fi chiar null) și întoarce:
    //   Ok(ProductCode)  – dacă textul are formatul corect
    //   Error(mesaj)     – dacă textul nu are formatul corect
    public static Result<ProductCode, string> Create(string? raw)
    {
        // Pasul 1: normalizăm textul. null devine "", eliminăm spațiile de la capete
        // și transformăm în litere mari, astfel încât "lp001" să fie acceptat ca "LP001".
        string text = (raw ?? "").Trim().ToUpperInvariant();

        // Pasul 2: verificăm formatul cu expresia regulată definită mai jos.
        if (Pattern().IsMatch(text))
        {
            return new Result<ProductCode, string>.Ok(new ProductCode(text));
        }

        return new Result<ProductCode, string>.Error($"Cod de produs invalid: '{raw}' (format așteptat: LP001)");
    }

    // Când afișăm un ProductCode (ex. în Console.WriteLine), vrem să apară doar textul codului.
    public override string ToString() => Value;

    // Expresia regulată:  ^ = început, [A-Z]{2} = exact 2 litere mari,
    //                     \d{3} = exact 3 cifre, $ = sfârșit.
    // [GeneratedRegex] îi cere compilatorului să genereze codul pentru regex (mai rapid).
    [GeneratedRegex(@"^[A-Z]{2}\d{3}$")]
    private static partial Regex Pattern();
}
