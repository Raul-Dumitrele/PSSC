using System.Globalization;

namespace ShoppingCart.Models;

// =====================================================================================
// Quantity – TIP VALOARE pentru cantitatea comandată dintr-un produs.
// =====================================================================================
// Regula: un număr întreg între 1 și 100 (inclusiv).
// La fel ca ProductCode, se poate crea doar prin Create, deci orice Quantity existent
// respectă regula de mai sus.
// =====================================================================================
public sealed record Quantity
{
    // Cantitatea maximă permisă pe o linie de comandă.
    public const int Max = 100;

    // Valoarea numerică a cantității (garantat între 1 și Max).
    public int Value { get; }

    // Constructor privat: se folosește doar din interiorul metodei Create.
    private Quantity(int value)
    {
        Value = value;
    }

    // Transformă textul introdus de utilizator într-o cantitate validă (sau o eroare).
    public static Result<Quantity, string> Create(string? raw)
    {
        // Pasul 1: încercăm să transformăm textul în număr întreg.
        // int.TryParse întoarce false (în loc să arunce excepție) dacă textul nu e un număr.
        // CultureInfo.InvariantCulture = interpretăm numărul la fel pe orice calculator.
        bool isNumber = int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value);

        // Pasul 2: verificăm că numărul este în intervalul permis.
        bool isInRange = value >= 1 && value <= Max;

        if (isNumber && isInRange)
        {
            return new Result<Quantity, string>.Ok(new Quantity(value));
        }

        return new Result<Quantity, string>.Error($"Cantitate invalidă: '{raw}' (număr între 1 și {Max})");
    }

    public override string ToString() => Value.ToString(CultureInfo.InvariantCulture);
}
