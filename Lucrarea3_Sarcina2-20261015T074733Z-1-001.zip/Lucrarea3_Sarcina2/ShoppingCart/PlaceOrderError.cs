using ShoppingCart.Models;

namespace ShoppingCart;

// =====================================================================================
// PlaceOrderError – motivul pentru care comanda NU a putut fi plasată.
// =====================================================================================
// Este rezultatul de EȘEC al workflow-ului (opusul lui OrderPlacedEvent).
// Un eșec nu este un "fapt petrecut", deci nu îl modelăm ca eveniment, ci ca eroare.
//
// Ca și la Result, constructorul privat face ca lista de erori posibile să fie ÎNCHISĂ:
// există exact cele patru tipuri de mai jos și niciunul în plus. Fiecare tip de eroare
// poartă exact datele de care avem nevoie pentru a explica problema.
// =====================================================================================
public abstract record PlaceOrderError
{
    private PlaceOrderError() { }

    // Pasul 1 (Validate) a eșuat: datele introduse nu respectă formatul.
    // Conține TOATE problemele găsite (nu doar prima), ca utilizatorul să le poată corecta pe toate odată.
    public sealed record Validation(IReadOnlyList<string> Messages) : PlaceOrderError;

    // Pasul 2 (CheckProducts) a eșuat: coduri cu format corect, dar care nu există în catalog.
    public sealed record UnknownProducts(IReadOnlyList<ProductCode> Codes) : PlaceOrderError;

    // Pasul 3 (CheckStock) a eșuat: nu avem destule bucăți dintr-unul sau mai multe produse.
    public sealed record InsufficientStock(IReadOnlyList<StockShortage> Shortages) : PlaceOrderError;

    // Pasul 4 (CheckDeliveryAddress) a eșuat: adresa e corectă, dar nu livrăm în acel oraș.
    public sealed record DeliveryNotAvailable(string City) : PlaceOrderError;

    // Transformă eroarea în mesaje text pe care le putem afișa utilizatorului.
    // "this switch" verifică ce tip concret de eroare avem și alege ramura potrivită.
    public IReadOnlyList<string> ToMessages()
    {
        switch (this)
        {
            case Validation validation:
                return validation.Messages;

            case UnknownProducts unknown:
                return unknown.Codes
                    .Select(code => $"Produs inexistent: {code}")
                    .ToList();

            case InsufficientStock stock:
                return stock.Shortages
                    .Select(s => $"Stoc insuficient pentru {s.Code}: cerut {s.Requested}, disponibil {s.Available}")
                    .ToList();

            case DeliveryNotAvailable delivery:
                return new List<string> { $"Nu livrăm în orașul {delivery.City}" };

            default:
                // Nu se poate ajunge aici, pentru că lista de erori este închisă.
                throw new InvalidOperationException("Tip de eroare necunoscut.");
        }
    }
}

// Detaliile unei lipse de stoc pentru un produs:
//   Code      – ce produs
//   Requested – câte bucăți s-au cerut (adunate de pe toate liniile comenzii)
//   Available – câte bucăți avem în stoc
public sealed record StockShortage(ProductCode Code, int Requested, int Available);
