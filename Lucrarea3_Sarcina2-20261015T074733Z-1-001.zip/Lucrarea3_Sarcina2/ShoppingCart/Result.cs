namespace ShoppingCart;

// =====================================================================================
// Result<TOk, TError> – rezultatul unei operații care POATE eșua.
// =====================================================================================
//
// În loc să aruncăm excepții (throw) când ceva nu e în regulă, funcțiile noastre întorc
// un Result. Un Result este întotdeauna EXACT UNUL dintre cele două cazuri:
//
//     Ok(valoare)    -> operația a reușit, iar "valoare" este rezultatul ei (de tip TOk)
//     Error(eroare)  -> operația a eșuat, iar "eroare" spune de ce (de tip TError)
//
// Exemplu:
//     Result<Quantity, string> r = Quantity.Create("5");    // r este Ok(Quantity 5)
//     Result<Quantity, string> r = Quantity.Create("abc");  // r este Error("Cantitate invalidă...")
//
// Avantajul: semnătura funcției îți spune clar că operația poate eșua, iar compilatorul
// te obligă să tratezi și cazul de eroare (vezi Match mai jos).
//
// Cele trei metode importante:
//     Match – "deschide" rezultatul: ce fac dacă e Ok și ce fac dacă e Error.
//     Map   – transformă valoarea din Ok cu o funcție care NU poate eșua.
//     Bind  – continuă cu un pas următor care POATE eșua (întoarce și el un Result).
// =====================================================================================
public abstract record Result<TOk, TError>
{
    // Constructorul este privat: nimeni din afara acestei clase nu poate crea alte cazuri
    // în afară de Ok și Error. Astfel știm sigur că un Result este ori Ok, ori Error.
    private Result() { }

    // Cazul de SUCCES. Conține valoarea produsă de operație.
    // Se creează așa: new Result<Quantity, string>.Ok(cantitate)
    public sealed record Ok(TOk Value) : Result<TOk, TError>;

    // Cazul de EȘEC. Conține informația despre eroare.
    // Se creează așa: new Result<Quantity, string>.Error("mesaj de eroare")
    public sealed record Error(TError Value) : Result<TOk, TError>;

    // -------------------------------------------------------------------------------
    // Match: tratează AMBELE cazuri și produce o singură valoare finală.
    // -------------------------------------------------------------------------------
    // Primești două funcții:
    //   onOk    – se apelează dacă rezultatul este Ok (primește valoarea de succes)
    //   onError – se apelează dacă rezultatul este Error (primește eroarea)
    // Doar UNA dintre ele se execută. Nu poți "uita" să tratezi eroarea.
    //
    // Exemplu:
    //   string text = Quantity.Create("5").Match(
    //       onOk:    q   => $"Cantitate: {q}",
    //       onError: err => $"Eroare: {err}");
    public T Match<T>(Func<TOk, T> onOk, Func<TError, T> onError)
    {
        if (this is Ok ok)
        {
            return onOk(ok.Value);
        }

        if (this is Error error)
        {
            return onError(error.Value);
        }

        // Nu se poate ajunge aici: constructorul privat garantează că există doar Ok și Error.
        throw new InvalidOperationException("Result trebuie să fie Ok sau Error.");
    }

    // -------------------------------------------------------------------------------
    // Map: transformă valoarea de succes cu o funcție care NU poate eșua.
    // -------------------------------------------------------------------------------
    //   Ok(x)    --Map(f)-->  Ok(f(x))      (aplicăm funcția)
    //   Error(e) --Map(f)-->  Error(e)      (funcția NU se apelează; eroarea merge mai departe)
    //
    // Exemplu: calculul prețului nu poate eșua, deci folosim Map(OrderOperations.Price).
    public Result<TNext, TError> Map<TNext>(Func<TOk, TNext> transform)
    {
        if (this is Ok ok)
        {
            TNext newValue = transform(ok.Value);
            return new Result<TNext, TError>.Ok(newValue);
        }

        Error error = (Error)this;
        return new Result<TNext, TError>.Error(error.Value);
    }

    // -------------------------------------------------------------------------------
    // Bind: continuă cu un pas următor care POATE eșua.
    // -------------------------------------------------------------------------------
    //   Ok(x)    --Bind(f)-->  f(x)          (f întoarce deja un Result: Ok sau Error)
    //   Error(e) --Bind(f)-->  Error(e)      (f NU se apelează; eroarea merge mai departe)
    //
    // Diferența față de Map: funcția dată la Bind întoarce ea însăși un Result.
    // Dacă am folosi Map cu o astfel de funcție, am obține Result<Result<...>> (un rezultat
    // în alt rezultat). Bind "aplatizează" acest lucru într-un singur Result.
    //
    // Ideea de "cale ferată" (railway): imaginează-ți două linii paralele – linia Ok și
    // linia Error. Fiecare Bind este un macaz: dacă pasul reușește rămânem pe linia Ok și
    // mergem la pasul următor; la PRIMA eroare trecem pe linia Error și toți pașii
    // rămași sunt săriți până la final.
    public Result<TNext, TError> Bind<TNext>(Func<TOk, Result<TNext, TError>> nextStep)
    {
        if (this is Ok ok)
        {
            return nextStep(ok.Value);
        }

        Error error = (Error)this;
        return new Result<TNext, TError>.Error(error.Value);
    }
}
