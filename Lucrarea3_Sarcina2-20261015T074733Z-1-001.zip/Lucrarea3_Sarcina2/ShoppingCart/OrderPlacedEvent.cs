using ShoppingCart.Models;
using ShoppingCart.States;

namespace ShoppingCart;

// =====================================================================================
// OrderPlacedEvent – EVENIMENTUL "comanda a fost plasată".
// =====================================================================================
// Un eveniment descrie un FAPT care s-a petrecut deja (de aceea numele este la timpul
// trecut: "Placed"). Acesta este rezultatul de SUCCES al workflow-ului.
//
// Dacă workflow-ul eșuează, NU se creează niciun eveniment – în schimb primim un
// PlaceOrderError (vezi PlaceOrderError.cs).
// =====================================================================================
public sealed record OrderPlacedEvent(
    Guid OrderId,                      // identificatorul unic al comenzii plasate
    Customer Customer,                 // cine a plasat comanda
    IReadOnlyList<PricedLine> Lines,   // produsele comandate, cu prețuri calculate
    Address DeliveryAddress,           // unde livrăm
    decimal Subtotal,                  // suma produselor
    decimal ShippingCost,              // costul transportului
    decimal Total,                     // Subtotal + ShippingCost
    DateTimeOffset PlacedAt);          // momentul plasării comenzii
