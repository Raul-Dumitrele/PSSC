using ShoppingCart.Models;

namespace ShoppingCart.States;

// =====================================================================================
// STĂRILE COMENZII
// =====================================================================================
// O comandă trece prin mai multe etape. În loc să avem o singură clasă "Order" cu multe
// câmpuri care uneori sunt completate și alteori nu, avem câte un TIP SEPARAT pentru
// fiecare etapă. Fiecare tip conține doar datele care au sens în acea etapă.
//
//   UnvalidatedOrder  --Validate-->       ValidatedOrder
//   ValidatedOrder    --CheckProducts-->  ResolvedOrder
//   ResolvedOrder     --CheckStock-->     ResolvedOrder (aceeași stare, doar verificată)
//   ResolvedOrder     --CheckDelivery-->  ResolvedOrder (aceeași stare, doar verificată)
//   ResolvedOrder     --Price-->          PricedOrder
//
// Avantaj: compilatorul impune ordinea pașilor. De exemplu, nu poți apela Price pe o
// comandă nevalidată, pentru că Price cere un ResolvedOrder, nu un UnvalidatedOrder.
// =====================================================================================

// -------------------------------------------------------------------------------------
// Etapa 1: comanda NEVALIDATĂ – text brut de la utilizator (orice câmp poate fi greșit).
// -------------------------------------------------------------------------------------
public sealed record UnvalidatedOrder(
    string? CustomerName,
    IReadOnlyList<UnvalidatedLine> Lines,
    string? Street,
    string? City,
    string? PostalCode);

// -------------------------------------------------------------------------------------
// Etapa 2: comanda VALIDATĂ – toate valorile au formatul corect (tipuri DDD),
// dar încă nu am verificat dacă produsele există în catalog sau dacă avem stoc.
// -------------------------------------------------------------------------------------
public sealed record ValidatedLine(ProductCode Code, Quantity Quantity);

public sealed record ValidatedOrder(
    Customer Customer,
    IReadOnlyList<ValidatedLine> Lines,
    Address DeliveryAddress);

// -------------------------------------------------------------------------------------
// Etapa 3: comanda REZOLVATĂ – în loc de un simplu cod, fiecare linie conține acum
// produsul real din catalog (cu nume, preț și stoc).
// -------------------------------------------------------------------------------------
public sealed record ResolvedLine(Product Product, Quantity Quantity);

public sealed record ResolvedOrder(
    Customer Customer,
    IReadOnlyList<ResolvedLine> Lines,
    Address DeliveryAddress);

// -------------------------------------------------------------------------------------
// Etapa 4: comanda PREȚUITĂ – știm cât costă fiecare linie și cât costă totul.
// -------------------------------------------------------------------------------------
public sealed record PricedLine(
    ProductCode Code,
    string Name,
    int Quantity,
    decimal UnitPrice,   // prețul unei bucăți
    decimal LineTotal);  // UnitPrice * Quantity

public sealed record PricedOrder(
    Customer Customer,
    IReadOnlyList<PricedLine> Lines,
    Address DeliveryAddress,
    decimal Subtotal,      // suma tuturor LineTotal
    decimal ShippingCost,  // costul transportului (0 dacă e gratuit)
    decimal Total);        // Subtotal + ShippingCost
