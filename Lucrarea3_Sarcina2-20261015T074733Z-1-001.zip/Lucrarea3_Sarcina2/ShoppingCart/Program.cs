using ShoppingCart;
using ShoppingCart.Models;

// =====================================================================================
// Program.cs – aplicația consolă (punctul de intrare).
// =====================================================================================
// Rolul acestui fișier este DOAR să comunice cu utilizatorul:
//   1. pregătește datele de test (catalog, orașe)
//   2. citește datele comenzii de la tastatură
//   3. apelează workflow-ul
//   4. afișează rezultatul (succes sau erori)
// Toată logica de afaceri se află în OrderOperations și PlaceOrderWorkflow.
// =====================================================================================

// Diacriticele (ș, ț, ă) trebuie citite și afișate corect indiferent de pagina de cod a consolei.
Console.InputEncoding = System.Text.Encoding.UTF8;
Console.OutputEncoding = System.Text.Encoding.UTF8;

// -------------------------------------------------------------------------------------
// 1. Date "de test" în loc de bază de date.
// -------------------------------------------------------------------------------------
List<Product> products = new List<Product>
{
    NewProduct("LP001", "Laptop", 3500m, 5),
    NewProduct("MS002", "Mouse", 80m, 50),
    NewProduct("KB003", "Tastatură", 150m, 2),
};

// Catalogul: putem găsi rapid un produs după cod (cheia dicționarului).
Dictionary<ProductCode, Product> catalog = new Dictionary<ProductCode, Product>();
foreach (Product product in products)
{
    catalog[product.Code] = product;
}

// Orașele în care livrăm. StringComparer.OrdinalIgnoreCase = "iași" și "Iași" sunt considerate la fel.
HashSet<string> deliveryCities = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
{
    "București", "Timișoara", "Cluj-Napoca", "Iași",
};

// Afișăm catalogul și orașele, ca utilizatorul să știe ce poate comanda.
Console.WriteLine("Catalog:");
foreach (Product product in products)
{
    // {product.Name,-10} = aliniat la stânga pe 10 caractere; {UnitPrice,8:0.00} = aliniat la dreapta pe 8, cu 2 zecimale.
    Console.WriteLine($"  {product.Code}  {product.Name,-10} {product.UnitPrice,8:0.00} lei  (stoc: {product.Stock})");
}

Console.WriteLine($"Livrăm în: {string.Join(", ", deliveryCities)}");
Console.WriteLine();

// -------------------------------------------------------------------------------------
// 2. Citim datele comenzii. Nu validăm nimic aici – doar colectăm textul brut.
// -------------------------------------------------------------------------------------
Console.Write("Numele clientului: ");
string? name = Console.ReadLine();

// Citim produse până când utilizatorul apasă Enter fără să scrie un cod.
List<UnvalidatedLine> lines = new List<UnvalidatedLine>();
Console.WriteLine("Produse (cod gol = terminat):");
while (true)
{
    Console.Write("  Cod produs: ");
    string? code = Console.ReadLine();
    if (string.IsNullOrWhiteSpace(code))
    {
        break;
    }

    Console.Write("  Cantitate: ");
    string? quantity = Console.ReadLine();

    lines.Add(new UnvalidatedLine(code, quantity));
}

Console.Write("Stradă: ");
string? street = Console.ReadLine();
Console.Write("Oraș: ");
string? city = Console.ReadLine();
Console.Write("Cod poștal: ");
string? postalCode = Console.ReadLine();

PlaceOrderCommand command = new PlaceOrderCommand(name, lines, street, city, postalCode);
Console.WriteLine();

// -------------------------------------------------------------------------------------
// 3. Rulăm workflow-ul. Rezultatul este fie Ok(OrderPlacedEvent), fie Error(PlaceOrderError).
// -------------------------------------------------------------------------------------
Result<OrderPlacedEvent, PlaceOrderError> result =
    PlaceOrderWorkflow.Execute(command, catalog, deliveryCities, DateTimeOffset.Now);

// -------------------------------------------------------------------------------------
// 4. Afișăm rezultatul. Match ne obligă să tratăm ambele cazuri.
//    Valoarea întoarsă (0 sau 1) devine codul de ieșire al programului:
//    0 = succes, 1 = eroare (convenția obișnuită pentru aplicațiile consolă).
// -------------------------------------------------------------------------------------
int exitCode = result.Match(
    onOk: placed => PrintSuccess(placed),
    onError: error => PrintErrors(error));

return exitCode;

// =====================================================================================
// Funcții ajutătoare (locale) folosite mai sus.
// =====================================================================================

// Afișează detaliile comenzii plasate și întoarce 0 (succes).
static int PrintSuccess(OrderPlacedEvent placed)
{
    Console.WriteLine($"Comanda {placed.OrderId} a fost plasată pentru {placed.Customer.Name} la {placed.PlacedAt:g}.");
    foreach (var line in placed.Lines)
    {
        Console.WriteLine($"  {line.Quantity} x {line.Name} ({line.Code}) la {line.UnitPrice:0.00} = {line.LineTotal:0.00} lei");
    }

    Console.WriteLine($"Subtotal: {placed.Subtotal:0.00} lei");
    Console.WriteLine($"Transport: {placed.ShippingCost:0.00} lei");
    Console.WriteLine($"Total: {placed.Total:0.00} lei");
    Console.WriteLine($"Livrare la: {placed.DeliveryAddress}");
    return 0;
}

// Afișează toate motivele pentru care comanda nu a fost plasată și întoarce 1 (eroare).
static int PrintErrors(PlaceOrderError error)
{
    Console.WriteLine("Comanda nu a putut fi plasată:");
    foreach (string message in error.ToMessages())
    {
        Console.WriteLine($"  - {message}");
    }

    return 1;
}

// Creează un produs pentru catalogul de test.
// ProductCode.Create întoarce un Result; aici știm sigur că codurile scrise de noi sunt corecte,
// așa că, dacă totuși am greșit unul, oprim programul cu o excepție (este o greșeală de programare).
static Product NewProduct(string code, string name, decimal price, int stock)
{
    ProductCode productCode = ProductCode.Create(code).Match(
        onOk: validCode => validCode,
        onError: message => throw new InvalidOperationException(message));

    return new Product(productCode, name, price, stock);
}
