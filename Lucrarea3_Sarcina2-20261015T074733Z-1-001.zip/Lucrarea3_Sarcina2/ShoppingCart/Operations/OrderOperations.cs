using ShoppingCart.Models;
using ShoppingCart.States;

namespace ShoppingCart.Operations;

// =====================================================================================
// OrderOperations – PAȘII workflow-ului "plasează comanda".
// =====================================================================================
// Fiecare metodă de aici este un pas care:
//   - primește comanda într-o anumită stare (ex. ValidatedOrder)
//   - întoarce comanda în starea următoare SAU o eroare (prin Result)
//
// Toate metodele sunt FUNCȚII PURE:
//   - nu citesc de la tastatură și nu scriu pe ecran
//   - nu modifică nimic în afara lor
//   - tot ce le trebuie (catalogul, lista de orașe) primesc ca parametri
// Așa, pentru aceleași date de intrare obții mereu același rezultat, iar testarea este simplă.
//
// Ordinea pașilor (vezi PlaceOrderWorkflow):
//   1. Validate              – textul introdus are formatul corect?
//   2. CheckProducts         – produsele există în catalog?
//   3. CheckStock            – avem destule bucăți în stoc?
//   4. CheckDeliveryAddress  – livrăm în orașul respectiv?
//   5. Price                 – calculăm prețul (acest pas nu poate eșua)
// =====================================================================================
public static class OrderOperations
{
    // De la această sumă (în lei) în sus, transportul este gratuit.
    public const decimal FreeShippingThreshold = 500m;

    // Costul transportului (în lei) pentru comenzile sub prag.
    public const decimal ShippingFee = 20m;

    // ---------------------------------------------------------------------------------
    // PASUL 1: Validare – transformăm textul brut în tipuri sigure (ProductCode, Quantity, Address).
    // ---------------------------------------------------------------------------------
    // Spre deosebire de pașii următori, aici NU ne oprim la prima eroare: adunăm TOATE
    // erorile într-o listă, ca utilizatorul să vadă dintr-o dată tot ce are de corectat.
    public static Result<ValidatedOrder, PlaceOrderError> Validate(UnvalidatedOrder order)
    {
        // Aici adunăm toate mesajele de eroare găsite.
        List<string> errors = new List<string>();

        // --- Numele clientului ---
        string name = (order.CustomerName ?? "").Trim();
        if (name.Length == 0)
        {
            errors.Add("Numele clientului lipsește");
        }

        // --- Lista de produse ---
        if (order.Lines.Count == 0)
        {
            errors.Add("Comanda nu conține niciun produs");
        }

        // --- Fiecare linie: cod de produs + cantitate ---
        List<ValidatedLine> validLines = new List<ValidatedLine>();
        foreach (UnvalidatedLine line in order.Lines)
        {
            // Încercăm să creăm codul și cantitatea. Fiecare Create întoarce Ok sau Error.
            Result<ProductCode, string> codeResult = ProductCode.Create(line.ProductCode);
            Result<Quantity, string> quantityResult = Quantity.Create(line.Quantity);

            // Dacă rezultatul este Error, adăugăm mesajul în listă.
            // ("is ... .Error codeError" verifică tipul și, dacă se potrivește,
            //  pune rezultatul în variabila codeError.)
            if (codeResult is Result<ProductCode, string>.Error codeError)
            {
                errors.Add(codeError.Value);
            }

            if (quantityResult is Result<Quantity, string>.Error quantityError)
            {
                errors.Add(quantityError.Value);
            }

            // Doar dacă AMBELE sunt Ok, avem o linie validă.
            if (codeResult is Result<ProductCode, string>.Ok code &&
                quantityResult is Result<Quantity, string>.Ok quantity)
            {
                validLines.Add(new ValidatedLine(code.Value, quantity.Value));
            }
        }

        // --- Adresa de livrare ---
        Result<Address, string> addressResult = Address.Create(order.Street, order.City, order.PostalCode);
        if (addressResult is Result<Address, string>.Error addressError)
        {
            errors.Add(addressError.Value);
        }

        // --- Decizia finală ---
        // Dacă am găsit cel puțin o eroare, întoarcem Error cu TOATE mesajele.
        if (errors.Count > 0)
        {
            return new Result<ValidatedOrder, PlaceOrderError>.Error(new PlaceOrderError.Validation(errors));
        }

        // Nu există erori, deci adresa este sigur Ok. O extragem din Result.
        Address address = ((Result<Address, string>.Ok)addressResult).Value;

        // Creăm clientul (cu un Id nou) și comanda validată.
        Customer customer = new Customer(Guid.NewGuid(), name);
        ValidatedOrder validatedOrder = new ValidatedOrder(customer, validLines, address);

        return new Result<ValidatedOrder, PlaceOrderError>.Ok(validatedOrder);
    }

    // ---------------------------------------------------------------------------------
    // PASUL 2: Verificăm că fiecare produs din comandă există în catalog.
    // ---------------------------------------------------------------------------------
    // Catalogul este un dicționar: cheia = codul produsului, valoarea = produsul.
    // Dacă toate codurile există, înlocuim fiecare cod cu produsul complet din catalog.
    public static Result<ResolvedOrder, PlaceOrderError> CheckProducts(
        ValidatedOrder order,
        IReadOnlyDictionary<ProductCode, Product> catalog)
    {
        List<ProductCode> unknownCodes = new List<ProductCode>();
        List<ResolvedLine> resolvedLines = new List<ResolvedLine>();

        foreach (ValidatedLine line in order.Lines)
        {
            // TryGetValue întoarce true și ne dă produsul dacă codul există în catalog.
            if (catalog.TryGetValue(line.Code, out Product? product))
            {
                resolvedLines.Add(new ResolvedLine(product, line.Quantity));
            }
            else if (!unknownCodes.Contains(line.Code))
            {
                // Același cod greșit poate apărea de mai multe ori; îl raportăm o singură dată.
                unknownCodes.Add(line.Code);
            }
        }

        if (unknownCodes.Count > 0)
        {
            return new Result<ResolvedOrder, PlaceOrderError>.Error(new PlaceOrderError.UnknownProducts(unknownCodes));
        }

        ResolvedOrder resolvedOrder = new ResolvedOrder(order.Customer, resolvedLines, order.DeliveryAddress);
        return new Result<ResolvedOrder, PlaceOrderError>.Ok(resolvedOrder);
    }

    // ---------------------------------------------------------------------------------
    // PASUL 3: Verificăm că avem destul stoc pentru fiecare produs.
    // ---------------------------------------------------------------------------------
    // Atenție: același produs poate apărea pe mai multe linii (ex. 2 mouse-uri, apoi încă 3).
    // De aceea mai întâi ADUNĂM cantitățile pe fiecare produs și abia apoi comparăm cu stocul.
    public static Result<ResolvedOrder, PlaceOrderError> CheckStock(ResolvedOrder order)
    {
        // Pasul 3a: câte bucăți s-au cerut în total din fiecare produs?
        Dictionary<Product, int> totalRequested = new Dictionary<Product, int>();
        foreach (ResolvedLine line in order.Lines)
        {
            totalRequested.TryGetValue(line.Product, out int alreadyRequested); // 0 dacă nu există încă
            totalRequested[line.Product] = alreadyRequested + line.Quantity.Value;
        }

        // Pasul 3b: pentru care produse se cere mai mult decât avem în stoc?
        List<StockShortage> shortages = new List<StockShortage>();
        foreach (KeyValuePair<Product, int> entry in totalRequested)
        {
            Product product = entry.Key;
            int requested = entry.Value;

            if (requested > product.Stock)
            {
                shortages.Add(new StockShortage(product.Code, requested, product.Stock));
            }
        }

        if (shortages.Count > 0)
        {
            return new Result<ResolvedOrder, PlaceOrderError>.Error(new PlaceOrderError.InsufficientStock(shortages));
        }

        // Stocul este suficient: comanda trece mai departe NESCHIMBATĂ.
        return new Result<ResolvedOrder, PlaceOrderError>.Ok(order);
    }

    // ---------------------------------------------------------------------------------
    // PASUL 4: Verificăm că livrăm în orașul din adresă.
    // ---------------------------------------------------------------------------------
    public static Result<ResolvedOrder, PlaceOrderError> CheckDeliveryAddress(
        ResolvedOrder order,
        IReadOnlySet<string> deliveryCities)
    {
        string city = order.DeliveryAddress.City;

        if (!deliveryCities.Contains(city))
        {
            return new Result<ResolvedOrder, PlaceOrderError>.Error(new PlaceOrderError.DeliveryNotAvailable(city));
        }

        // Livrăm în acest oraș: comanda trece mai departe NESCHIMBATĂ.
        return new Result<ResolvedOrder, PlaceOrderError>.Ok(order);
    }

    // ---------------------------------------------------------------------------------
    // PASUL 5: Calculăm prețul comenzii.
    // ---------------------------------------------------------------------------------
    // Acest pas NU poate eșua (orice comandă rezolvată are un preț), deci întoarce direct
    // PricedOrder, nu un Result. De aceea în workflow îl apelăm cu Map, nu cu Bind.
    public static PricedOrder Price(ResolvedOrder order)
    {
        // Prețul fiecărei linii = preț unitar * cantitate.
        List<PricedLine> pricedLines = new List<PricedLine>();
        foreach (ResolvedLine line in order.Lines)
        {
            int quantity = line.Quantity.Value;
            decimal unitPrice = line.Product.UnitPrice;
            decimal lineTotal = unitPrice * quantity;

            pricedLines.Add(new PricedLine(line.Product.Code, line.Product.Name, quantity, unitPrice, lineTotal));
        }

        // Subtotalul = suma tuturor liniilor.
        decimal subtotal = pricedLines.Sum(line => line.LineTotal);

        // Transport gratuit de la FreeShippingThreshold în sus, altfel plătim ShippingFee.
        decimal shipping = subtotal >= FreeShippingThreshold ? 0m : ShippingFee;

        decimal total = subtotal + shipping;

        return new PricedOrder(order.Customer, pricedLines, order.DeliveryAddress, subtotal, shipping, total);
    }
}
