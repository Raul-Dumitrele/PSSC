namespace ShoppingCart;

// =====================================================================================
// PlaceOrderCommand – COMANDA (intenția) utilizatorului: "vreau să plasez o comandă".
// =====================================================================================
// Conține datele EXACT așa cum le-a introdus utilizatorul: text brut, NEVALIDAT.
// De aceea toate câmpurile sunt string? (pot fi null, goale sau greșite).
// Validarea și transformarea în tipuri sigure (ProductCode, Quantity, Address) se fac
// abia în primul pas al workflow-ului: OrderOperations.Validate.
// =====================================================================================

// O linie din comandă, așa cum a fost scrisă: un cod de produs și o cantitate, ambele text.
// Ex.: new UnvalidatedLine("lp001", "2")
public sealed record UnvalidatedLine(string? ProductCode, string? Quantity);

// Toate datele necesare pentru a plasa o comandă.
public sealed record PlaceOrderCommand(
    string? CustomerName,
    IReadOnlyList<UnvalidatedLine> Lines,
    string? Street,
    string? City,
    string? PostalCode);
