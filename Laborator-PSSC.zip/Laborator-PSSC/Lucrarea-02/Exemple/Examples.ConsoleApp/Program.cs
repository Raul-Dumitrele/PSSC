using System.Globalization;
using System.Text;
using Examples.Domain.Entities;
using Examples.Domain.States;
using Examples.Domain.ValueObjects;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;

Address address = Address.Create(
    "Strada Exemplu 10",
    "București",
    "010101");

Customer customer = new Customer(
    Guid.NewGuid(),
    "Ion Popescu",
    address);

ShoppingCart cart = ShoppingCart.Create(
    Guid.NewGuid(),
    customer);

while (true)
{
    Console.WriteLine();
    Console.WriteLine("===== COȘ DE CUMPĂRĂTURI =====");
    Console.WriteLine($"Stare: {GetCartState(cart)}");
    Console.WriteLine();

    Console.WriteLine("1. Adaugă produs");
    Console.WriteLine("2. Validează coșul");
    Console.WriteLine("3. Plătește coșul");
    Console.WriteLine("4. Afișează coșul");
    Console.WriteLine("0. Ieșire");

    Console.Write("Alege opțiunea: ");

    string? option = Console.ReadLine();

    switch (option)
    {
        case "1":
            AddProduct(cart);
            break;

        case "2":
            cart.Validate();
            Console.WriteLine("Coșul a fost validat.");
            break;

        case "3":
            cart.Pay();
            Console.WriteLine("Coșul a fost plătit.");
            break;

        case "4":
            DisplayCart(cart);
            break;

        case "0":
            Console.WriteLine("La revedere!");
            return;

        default:
            Console.WriteLine("Opțiune invalidă.");
            break;
    }
}

static string GetCartState(IShoppingCart cart)
{
    return cart.State switch
    {
        ShoppingCartState.Empty =>
            "Coș gol",

        ShoppingCartState.Unvalidated =>
            "Coș nevalidat",

        ShoppingCartState.Validated =>
            "Coș validat",

        ShoppingCartState.Paid =>
            "Coș plătit",

        _ =>
            "Stare necunoscută"
    };
}

static void AddProduct(IShoppingCart cart)
{
    Console.Write("Cod produs: ");
    string? code = Console.ReadLine();

    Console.Write("Nume produs: ");
    string? name = Console.ReadLine();

    Console.Write("Preț produs: ");
    decimal price = decimal.Parse(
        Console.ReadLine()!,
        CultureInfo.InvariantCulture);

    Console.Write("Cantitate: ");
    int quantity = int.Parse(
        Console.ReadLine()!,
        CultureInfo.InvariantCulture);

    ProductCode productCode =
        ProductCode.Create(code!);

    Quantity productQuantity =
        Quantity.Create(quantity);

    cart.AddProduct(
        productCode,
        productQuantity);

    Console.WriteLine(
        $"Produsul {name} a fost adăugat.");
}

static void DisplayCart(IShoppingCart cart)
{
    Console.WriteLine();
    Console.WriteLine("--- CONȚINUT COȘ ---");

    if (cart.Products.Count == 0)
    {
        Console.WriteLine("Coșul este gol.");
        return;
    }

    foreach (var product in cart.Products)
    {
        Console.WriteLine(
            $"Cod: {product.ProductCode}, " +
            $"Cantitate: {product.Quantity}");
    }

    Console.WriteLine(
        $"Număr produse: {cart.Products.Count}");
}
