namespace Examples.Domain.States;

public abstract record ShoppingCartState
{
    private ShoppingCartState()
    {
    }

    public sealed record Empty : ShoppingCartState;

    public sealed record Unvalidated : ShoppingCartState;

    public sealed record Validated : ShoppingCartState;

    public sealed record Paid : ShoppingCartState;
}
