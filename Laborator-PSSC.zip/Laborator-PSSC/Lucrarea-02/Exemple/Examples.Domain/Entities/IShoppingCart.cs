using Examples.Domain.States;
using Examples.Domain.ValueObjects;

namespace Examples.Domain.Entities;

public interface IShoppingCart
{
    Guid Id { get; }

    Customer Customer { get; }

    ShoppingCartState State { get; }

    List<(ProductCode ProductCode, Quantity Quantity)> Products { get; }

    void AddProduct(
        ProductCode productCode,
        Quantity quantity);

    void Validate();

    void Pay();
}
