using Examples.Domain.States;
using Examples.Domain.ValueObjects;

namespace Examples.Domain.Entities;

public class ShoppingCart : IShoppingCart
{
    public Guid Id { get; }

    public Customer Customer { get; }

    public ShoppingCartState State { get; private set; }

    public List<(ProductCode ProductCode, Quantity Quantity)> Products { get; }

    private ShoppingCart(
        Guid id,
        Customer customer)
    {
        Id = id;
        Customer = customer;
        State = new ShoppingCartState.Empty();
        Products = new List<(ProductCode, Quantity)>();
    }

    public static ShoppingCart Create(
        Guid id,
        Customer customer)
    {
        return new ShoppingCart(id, customer);
    }

    public void AddProduct(
        ProductCode productCode,
        Quantity quantity)
    {
        Products.Add((productCode, quantity));
        State = new ShoppingCartState.Unvalidated();
    }

    public void Validate()
    {
        State = new ShoppingCartState.Validated();
    }

    public void Pay()
    {
        State = new ShoppingCartState.Paid();
    }
}
