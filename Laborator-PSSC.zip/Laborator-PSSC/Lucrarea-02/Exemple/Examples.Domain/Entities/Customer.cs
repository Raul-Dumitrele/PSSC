using Examples.Domain.ValueObjects;

namespace Examples.Domain.Entities;

public class Customer
{
    public Guid Id { get; }
    public string Name { get; }
    public Address Address { get; }

    public Customer(
        Guid id,
        string name,
        Address address)
    {
        Id = id;
        Name = name;
        Address = address;
    }
}
