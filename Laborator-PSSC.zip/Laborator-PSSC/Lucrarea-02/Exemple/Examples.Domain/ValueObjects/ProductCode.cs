namespace Examples.Domain.ValueObjects;

public sealed record ProductCode
{
    public string Value { get; }

    private ProductCode(string value)
    {
        Value = value;
    }

    public static ProductCode Create(string value)
    {
        return new ProductCode(value);
    }

    public override string ToString()
    {
        return Value;
    }
}
