namespace Examples.Domain.ValueObjects;

public sealed record Address
{
    public string Street { get; }
    public string City { get; }
    public string PostalCode { get; }

    private Address(
        string street,
        string city,
        string postalCode)
    {
        Street = street;
        City = city;
        PostalCode = postalCode;
    }

    public static Address Create(
        string street,
        string city,
        string postalCode)
    {
        return new Address(street, city, postalCode);
    }

    public override string ToString()
    {
        return $"{Street}, {City}, {PostalCode}";
    }
}
